//require("dotenv").config();
const express = require("express");
const session = require("express-session");

const globalErrHandler = require("./middlewares/globalHandler");



const app = express();

app.use(
  session({
    secret: "udgbnviohufcnhhu",
    resave: true,
    saveUninitialized: true,
    cookie: { maxage: 6000 },
  })
);



const route  = require("./routes/routes");

//const protected = require("../../middleware/protected");

//const my = require("./model/my/my");
//const userroute = require("./routes/user/user");






//app.use();


require("./config/dbConnect");



//compile the schema to form a model





// app.use((req, res, next) => {
//   if (req.session.userAuth) {
//     res.locals.userAuth = req.session.userAuth;
//   } else {
//     res.locals.userAuth = null;
//   }
//   next();
// });











//require("./config/dbConnect");



//view engine setup ejs
app.set("view engine", "ejs");



//middlewares
//app.use("/", userroute);
//configure ejs
//app.set("view engine", "ejs");
//serve static files
//app.use(express.static(__dirname + "/public"));
app.use(express.static(__dirname, +"/vendor"));
app.use(express.json()); //pass incoming data
app.use(express.urlencoded({ extended: true })); //pass form data
//session config

//Home page


app.use("", route);








// app.get("/cars", async (req, res) => {
//   const user = await User.findById(req.params.id);
//   res.render("cars");
// });




////////////////////////////////////////////////////////////////


// render services

// app.get("/maintainance_service", async function (req, res) {
//   res.render("maintainance_service");
// })









/////////////////////////////////////////////////////////



app.use(globalErrHandler);

const PORT = process.env.PORT || 9000;
app.listen(PORT, console.log(`Server is running on http://localhost:${PORT}`));
