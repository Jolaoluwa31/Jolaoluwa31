const mongoose = require("mongoose");

const dbConnect = async () => {
  console.log(process.env);
  try {
    await mongoose.connect("mongodb://localhost:27017/vm");
    console.log("DB Connected Successfully");
  } catch (error) {
    console.log("DB Connection failed", error.message);
  }
};

dbConnect();
