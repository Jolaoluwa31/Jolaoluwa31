const express = require("express");

const User = require("../model/user/User");
const Blog = require("../model/blogcomment/blogcomment");
const Contact = require("../model/contactcomment/contactcomment");
const Cardetails = require("../model/cardetails/cardetails");
const Maintenance = require("../model/maintenance/maintenance");
//const bcryptjs = require("bcryptjs");
const bcrypt = require("bcryptjs/dist/bcrypt");
const multer = require("multer");
const Admin = require("../model/admin/admin");
//const my = require("../model/my/my");

//const Maintenance = require("./model/maintenance/maintenance");

const protected = (req, res, next) => {
  if (!req.session.loginuser) {
   res.render("unauthorized");
    
  }
  else if(!req.session.loginadmin){
    res.render("unauthorized");
  }
  
  else {
    next();
  }
};

const protected1 = (req, res, next) => {
  if (!req.session.loginadmin) {
   res.render("unauthorized");
    
  } else {
    next();
  }
};

const route = express.Router();

route.get("/", async function (req, res) {
  const car = await Cardetails.find()
  
  res.render("index",{car});
});
route.get("/index",async function (req, res) {
  const car = await Cardetails.find()

  res.render("index",{car});
});




// });
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "./uploads");
  },
  filename: function (req, file, cb) {
    cb(null, file.filename + "_" + Date.now() + "_" + file.originalname);
  },
});

const upload = multer({
  storage: storage,
  //dest:"/uploads"
}).single("image");


route.get("/logout", function (req, res) {
  req.session.destroy(() => {
    res.redirect("/");
  });
})
// route.get("/car",protected,  async (req, res) => {
//   const userid = req.session.loginuser;
//   const user = await User.findById(userid);
//   const car = await Cardetails.findById(req.params.id);
  
//   res.render("car-details", {car,user});
// });



///////////////////////////////////////////////////////
// User registration

route.get("/dealers_signup", async function (req, res) {
  res.render("dealers_signup",{
    error:""
  });
});

route.post("/dealers_signup", async function (req, res) {
  const { name, email, password, phonenumber, address } = req.body;
  if (!name || !email || !password || !phonenumber || !address) {
    return res.render("dealers_signup", {
      error:"All fields are required",
    });
  }
  const salt = await bcrypt.genSalt(10);
  const hashedpass = await bcrypt.hash(password, salt);

  try {
    //1. check if user exist (email)
    const userFound = await User.findOne({ email });
    //throw an error
    if (userFound) {
      return res.render("dealers_signup", {
        error:"User already exist",
      });
    }

    const dealer = await User.create({
      name,
      email,
      password: hashedpass,
      phonenumber,
      address,
    });
    res.redirect("login_sell");
    //res.json({ name, email, password: hashedpass, phonenumber, address });
  } catch (err) {
    console.error(err);
  }
});

// User login
route.get("/login_sell", async function (req, res) {
  res.render("login_sell",{
    error:"",
  });
});
route.post("/login_sell", async (req, res) => {
  //console.log(req.body);
  const { email, password } = req.body;
  if (!email || !password) {
    return res.render("login_sell", {
      error:"All fields are required",
    });
  }

  const userFound = await User.findOne({ email });
  if (!userFound) {
    return res.render("login_sell", {
      error:"Invalid login credentials",
    });
  }

  const isPasswordValid = await bcrypt.compare(password, userFound.password);
  if (!isPasswordValid) {
    return res.render("login_sell", {
      error:"Invalid login credentials",
    });
  }
  req.session.loginuser = userFound;
   const userid = req.session.loginuser;
   const user = User.findOne(userid);
  res.redirect("beginning");
  // res.json({ msg: "Login successfully" ,
  //   data:user
  // });
});

route.get("/beginning",protected, async function (req, res) {
  const userid = req.session.loginuser;
  const user = await User.findById(userid);

 

  res.render("beginning", { user,  });
});

route.get("/cars", protected, async (req, res) => {
  const userid = req.session.loginuser;
  
  let user = await User.findById(userid);

 

  const car = await Cardetails.find()
  

  res.render("cars", { user,car });
});
route.get("/services_dealer",protected, async (req, res) => {
  const userid = req.session.loginuser;
  const user = await User.findById(userid);


  const maint = await Maintenance.find();
 res.render("services_dealer", { user,maint});
});

route.get("/team", async function (req, res) {
  res.render("team");
});

//sell cars
route.get("/input_car_details",protected, async function (req, res) {
  res.render("input_car_details",{
    error:"",
  });
});


route.get("/dcontact", protected,async function(req, res) {
  const userid = req.session.loginuser;
  const user = await User.findById(userid);



  res.render("contact_dealer",{user,
    error:"",
  });
});
route.post("/dcontact", protected,async function (req, res) {

  const userid = req.session.loginuser;
  const user = await User.findById(userid);

  const { name, email,subject, message } = req.body;
  if (!name || !email ||!subject || !message) {
    res.json({ message: "all field is required" });
  }
  try {
    const contact = await Contact.create({
      name,
      email,subject,
      message,
    });
    // return res.json({ message: "blog created" });
    res.redirect("beginning");
  } catch (error) {
    res.render("/contact_dealer",{ 
      error: "Your message has not been sent",
    })
  }
});










 / //////////////////////////////////////////////////////////////////////////////////////
  ////Ordinary user
  route.get("/services", async (req, res) => {
    
  const maint = await Maintenance.find();
    res.render("services",{maint});
  });

route.get("/blog", (req, res) => {
  res.render("blog");
});
route.get("/blog-details",(req,res) => {
  res.render("blog-details");
})
route.get("/team", (req, res) => {
  res.render("team");
});

route.get("/terms", (req, res) => {
  res.render("terms");
});

route.get("/testimonials", (req, res) => {
  res.render("testimonials");
});
route.get("/about-us", (req, res) => {
  res.render("about-us");
});

///////////////////////////////////////////////////////////////
//blog
route.post("/blog", async function (req, res) {
  const { name, email,topic, message } = req.body;
  if (!name || !email ||!topic || !message) {
    res.json({ message: "all field is required" });
  }
  try {
    const blog = await Blog.create({
      name,
      email,
      topic,
      message,
    });
    return res.json({ message: "blog created" });
  } catch (error) {
    res.json({ message: "error creating blog" });
  }
});

/////////////////////////////////////////////////////////////////////////////

//comment
route.get("/contact", function(req, res) {
  res.render("contact",{
    error:"",
  });
});
route.post("/contact", async function (req, res) {
  const { name, email,subject, message } = req.body;
  if (!name || !email ||!subject || !message) {
    res.json({ message: "all field is required" });
  }
  try {
    const contact = await Contact.create({
      name,
      email,subject,
      message,
    });
    // return res.json({ message: "blog created" });
    res.redirect("index")
  } catch (error) {
    res.render("/contact",{ 
      error: "Your message has not been sent",
    })
  }
});

/////////////////////////////////////////////////////////////////
//main_req
route.get('/maintainance_service',protected,(req, res) => {
  res.render('maintainance_service',{
    error:""
  });
})
route.post("/maintainance_service", upload,async function (req, res) {
  //console.log(req.body);
  //console.log(req.file);
  const {
    name,
    email,

     phonenumber,
    location,
    year,
    area,
   
  } = req.body;
  image = req.file.path;
 
  try {
    //1. check if user exist (email)
    const mainuser = await Maintenance.findOne({ email });
    //throw an error
    if (mainuser) {
      //return res.json({ message: "user exist" });
      return res.render("maintainance_service", {
        error:"user already exist",
      });

    }else{
      const main = await Maintenance.create({
        name,
        email,
        // password: hashedpass,
        phonenumber,
        location,
        year,
        area,
        image
      });
      res.redirect("beginning");
    }

    
    
  } catch (err) {
    console.error(err);
  }
});

////////////////////////////////////////////////////
//car details

route.get("/details", async function(req, res){
  const det = await Cardetails.findOne(detail);
  console.log(det);
});



//////////////////////////////////////////////
//adminreg

route.get("/adminpage",protected1, async (req, res)=>{
  const dealer = await User.find()
  const maint = await Maintenance.find()
  const info = await Contact.find()
  const card = await Cardetails.find()
  res.render("admin/admin_page",{dealer,maint,info,card})
});

route.get("/adminlogin",(req, res)=>{
  res.render("admin/admin_login",{error:""})
});

route.post("/adminlogin",async (req, res)=>{
  const { username, password } = req.body;

  const adminfound = await Admin.findOne({ username });
  if (!adminfound) {
    return res.render("admin/admin_login", {
      error:"Invalid login credentials",
    });
  }

  const isPasswordValid = await bcrypt.compare(password, adminfound.password);
  if (!isPasswordValid) {
    return res.render("admin/admin_login", {
      error:"Invalid login credentials",
    });
  }
  req.session.loginadmin = adminfound;
   const adminid = req.session.loginadmin;
   const adm = Admin.findOne(adminid);
  res.redirect("adminpage");
})

route.get("/deletecar/:id",async function (req, res) {
  const id = req.params.id;
  try {
    await Cardetails.findByIdAndDelete(id);
    res.redirect("/adminpage");
    
  } catch (error) {
    res.send(error.message);
    
  }
 
 
  });

route.get("/deleteinfo/:id",async function (req, res) {
    const id = req.params.id;
    try {
      await User.findByIdAndDelete(id);
      res.redirect("/adminpage");
      
    } catch (error) {
      res.send(error.message);
      
    }
   
   
    });
  
route.get("/deletemaint/:id",async function (req, res) {
      const id = req.params.id;
      try {
        await Maintenance.findByIdAndDelete(id);
        res.redirect("/adminpage");
        
      } catch (error) {
        res.send(error.message);
        
      }
     
     
      });
route.get("/deletecont/:id",async function (req, res) {
        const id = req.params.id;
        try {
          await Contact.findByIdAndDelete(id);
          res.redirect("/adminpage");
          
        } catch (error) {
          res.send(error.message);
          
        }
       
       
        });

 route.get("/adminreg",(req, res)=>{
   res.render("admin/adminreg",{error:""})
 });
 route.post("/adminreg",async (req, res)=>{
   const {username, password} =req.body;

   const salt = await bcrypt.genSalt(10);
   const hashedpass = await bcrypt.hash(password, salt);

   try {
     //1. check if user exist (email)
     const userFound = await Admin.findOne({username });
     //throw an error
     if (userFound) {
       return res.render("admin/adminreg", {
         error:"User already exist",
       });
     }
     const adm = await Admin.create({
       username,
       password: hashedpass,
     });
     res.redirect("adminlogin");
   
   } catch (err) {
     console.error(err);
   }

 });




route.post("/input_car_details", upload, async function (req, res) {


   const {

    name,
    email,
    phonenumber,
    location,
    make,
    model,
    year,
    mileage,
    price,
    transmission,
    fueltype,
    condition,
    description,
  } = req.body;
   const image = req.file.path;

  


  // // if (
  // //   !name ||
  // //   !email ||
  // //   !phonenumber ||
  // //   !location ||
  // //   !make ||
  // //   !model ||
  // //   !year ||
  // //   !mileage ||
  // //   !price ||
  // //   !transmission ||
  // //   !fueltype ||
  // //   !condition ||
  // //   !description ||
  // //   !image
  // // ) {
  // // //   res.json({ message: "all field is required" });
  // // // }

  try {
    const cardetail = await Cardetails.create({
      name,
      email,
      phonenumber,
      location,
      make,
      model,
      year,
      mileage,
      price,
      transmission,
      fueltype,
      condition,
      description,
      image,
    });
    res.redirect("beginning");
  } catch (error) {
    return res.render("input_car_details", {
      error:"Could not register",
    });
  }
});

route.get("/deactvate",(req, res) => {
  res.render("car")
});

route.get("/car/:id", async (req, res) => {
  // const userid = req.session.loginuser;
  // const user = await User.findById(userid);
  const car = await Cardetails.findById(req.params.id);
  
  res.render("car-details", {car});
});

route.get("/car/:id", async (req, res) => {
  // const userid = req.session.loginuser;
  // const user = await User.findById(userid);
  const car = await Cardetails.findById(req.params.id);
  
  res.render("car-detail", {car});
});

module.exports = route;
