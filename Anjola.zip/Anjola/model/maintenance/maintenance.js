const mongoose = require("mongoose");

//Schema
const maintenanceSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: true,
    },

    phonenumber: {
      type: Number,
      required: true,
    },
    location: {
      type: String,
      required: true,
    },
    year: {
      type: Number,
      required: true,
    },
    area: {
      type: String,
      required: true,
    },
    image: {
      type: String,
      required: true,
    },
  },
  {
    timestamps: true,
  }
);

//compile the schema to form a model
const Maintenance = mongoose.model("Maintenance", maintenanceSchema);

module.exports = Maintenance;
