const mongoose = require("mongoose");

//Schema
const mySchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    image:{
      type: String,
      required: true,
    },
    
  },
  {
    timestamps: true,
  }
);

//compile the schema to form a model
const my = mongoose.model("my", mySchema);

module.exports = my;
