const mongoose = require("mongoose");

//Schema
const cardetailsSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: true,
    },

    phonenumber: {
      type: Number,
      required: true,
    },
    location: {
      type: String,
      required: true,
    },
    make: {
      type: String,
      required: true,
    },
    model: {
      type: String,
      required: true,
    },

    year: {
      type: Number,
      required: true,
    },
    mileage: {
      type: Number,
      required: true,
    },
    price: {
      type: Number,
      required: true,
    },
    transmission: {
      type: String,
      required: true,
    },

    fueltype: {
      type: String,
      required: true,
    },
    condition: {
      type: String,
      required: true,
    },
    description: {
      type: String,
      required: true,
    },
    image: {
      type: String,
      required: true,
    },
  },
  {
    timestamps: true,
  }
);

//compile the schema to form a model
const Cardetails = mongoose.model("Cardetails", cardetailsSchema);

module.exports = Cardetails;
