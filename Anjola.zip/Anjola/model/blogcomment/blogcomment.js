const mongoose = require("mongoose");

//Schema
const blogSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    
    email: {
      type: String,
      required: true,
    },
    topic: {
      type: String,
      required: true,
    
  },
    message: {
      type: String,
      required: true,
    
  },
},
  {
    timestamps: true,
  }
);

//compile the schema to form a model
const Blog = mongoose.model("Blog", blogSchema);

module.exports = Blog;