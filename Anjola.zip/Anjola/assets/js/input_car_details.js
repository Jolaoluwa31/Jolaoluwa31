const form = document.getElementById('car-details-form');

form.addEventListener('submit', (e) => {
  e.preventDefault();
  const make = document.getElementById('make').value;
  const model = document.getElementById('model').value;
  const year = document.getElementById('year').value;
  const mileage = document.getElementById('mileage').value;
  const price = document.getElementById('price').value;
  const transmission = document.getElementById('transmission').value;
  const fuelType = document.getElementById('fuel-type').value;
  const condition = document.getElementById('condition').value;
  const description = document.getElementById('description').value;
  
  // Send data to server or database using AJAX or Fetch API
  fetch('/car-details', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      make,
      model,
      year,
      mileage,
      mileage,
      price,
      transmission,
      fuelType,
      condition,
      description
    })
  })
  .then((response) => response.json())
  .then((data) => console.log(data))
  .catch((error) => console.error(error));
});

